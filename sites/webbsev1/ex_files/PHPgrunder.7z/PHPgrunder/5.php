<?php include "functions.php"; ?>
<?php include "includes/header.php";?>
	<section class="content">

		<aside class="col-xs-4">
		<?php Navigation();?>
			
			
		</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

	
	<?php 

	// 1: Skriv ut variabeln den s.k supergolbala variabeln $_SERVER['PHP_SELF'] . Vad skrivs ut?


	// 2: Använd dig av den s.k superglobala variabeln $GET['lang'] som har attributet 'lang'. 
	//Använd en if-sats för att avgöra om språket på sidan är satt till engelska 'eng'. Skriv i så fall ut "Hello and welcome to our web page". 
	
?>





</article><!--MAIN CONTENT-->
<?php include "includes/footer.php"; ?>
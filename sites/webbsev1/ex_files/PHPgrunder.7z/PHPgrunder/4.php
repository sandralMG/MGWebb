<?php include "functions.php"; ?>
<?php include "includes/header.php";?>

	<section class="content">

	<aside class="col-xs-4">

		<?php Navigation();?>
			
		
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

	
	<?php  

// 1: Skapa en funktion och gör så att den returnerar produkton av två tal


// 2: Skriv ut produktion med med print istället för echo. 


// 3: Vad är skillnaden mellan print och echo?

	
?>





</article><!--MAIN CONTENT-->


<?php include "includes/footer.php"; ?>
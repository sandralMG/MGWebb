<?php include "functions.php"; ?>
<?php include "includes/header.php";?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">
		


		<?php  


         echo "Detta är en utskrift i php med kommandot echo.";
         $t=time();
         echo "<br>";
         echo("Dagens datum: " . date("Y-m-d",$t));
         echo "<br>";
         echo "Lycka till med uppgifterna!";
		

		?>

	

		</article><!--MAIN CONTENT-->

<?php include "includes/footer.php"; ?>
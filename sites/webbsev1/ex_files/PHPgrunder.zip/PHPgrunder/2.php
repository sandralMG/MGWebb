<?php include "functions.php"; ?>
<?php include "includes/header.php";?>

	<section class="content">

		<aside class="col-xs-4">

	<?php Navigation();?>
			
			
		</aside><!--SIDEBAR-->


		<article class="main-content col-xs-8">
		

<?php


		  
			// 1: Skapa två variabler number1 och number2 vardera tilldeles talet 10 och 20;


			// 2: Beräkna summan av de två talen och använd echo för att skriva ut svaret


			// 3: Skapa en array med de två talen och använd echo för att skriva ut talen i arrayen

	
			// 4: Skriv ut samma tal men denna gång med en s.k associative array. Denna gång, skriv ut värdena med funktionen print_r istället för echo
		


		?>

	

		</article><!--MAIN CONTENT-->

<?php include "includes/footer.php"; ?>
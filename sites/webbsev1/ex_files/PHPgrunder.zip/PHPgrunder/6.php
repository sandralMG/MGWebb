<?php include "functions.php"; ?>
<?php include "includes/header.php";?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">
		


		<?php  


		 
		   //1: Använd echo för att skriva ut strängen "I'm learning PHP"


		   //2: Använd echo och skriv ut Hello i ett <h1>-element


		   
			//3: Deklarera en variabel $name tilldela den en sträng som är ditt namn.
			
	
			
			//4: Använd echo för att skriva ut 'Hej jag heter $name' (single qoutes)

		
			//5: Skriv ut en radbrytning <br/>


			//6: Använd echo för att skriva ut "Hej jag heter $name" (single qoutes) 

		
			//7: Vad är skillnaden mellan single qoutes och double qoutes?

		?>

	

		</article><!--MAIN CONTENT-->

<?php include "includes/footer.php"; ?>
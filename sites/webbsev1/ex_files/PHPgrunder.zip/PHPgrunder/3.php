<?php include "functions.php"; ?>
<?php include "includes/header.php";?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

	// 1. Skriv en for-loop som skrivet ut 10 tal med echo 



	// 2. Tilldela en variabel $t = date("H"); . Använd en if-sats 
    //och använd echo för att skriva ut "Snart slutar vi lektionen" om värdet är mindre än 14


	
?>






</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php"; ?>